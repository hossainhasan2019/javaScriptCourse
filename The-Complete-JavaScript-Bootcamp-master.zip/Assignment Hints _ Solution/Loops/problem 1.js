/* 
  Problem 1
  ----------
  
  [Hints]
  সবচেয়ে সহজ প্রবলেম। ১ থেকে ১০০ পর্যন্ত লুপের মাধ্যমে যেতে হবে এবং প্রতিটি সংখ্যা 
  Console.log() এর মাধ্যমে Console এ Show করতে হবে। 

*/

for (let index = 1; index <= 100; index++) {
  console.log(index);
}
