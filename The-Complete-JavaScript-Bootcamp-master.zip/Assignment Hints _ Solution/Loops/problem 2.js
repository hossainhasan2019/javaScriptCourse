/* 
  Problem 2
  ----------

  [Hints]
  এখানে Loop Variable এর মান ১০০ থেকে শুরু করতে হবে। প্রতি লুপে এর মান, এক এক করে কমাতে হবে। যখন Loop Variable এর মান ১ এর থেকেও ছোট হয়ে যাবে, তখন লুপ ব্রেক হবে।
*/

for (let index = 100; index >= 1; index--) {
  console.log(index);
}
