/* 
  Problem 7
  ----------

  [Hints]
  Basic Loop Problem.

  */

let number = 15;

for (let multiplier = 1; multiplier <= 10; multiplier++) {
  let product = number * multiplier;
  console.log(`${number} x ${multiplier} = ${product}`);
}
